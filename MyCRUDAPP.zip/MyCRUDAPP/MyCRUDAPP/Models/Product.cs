﻿

using System;
using System.ComponentModel.DataAnnotations;

namespace MyCRUDAPP.Models
{
    public class Product
    {
        public int? Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        public string Detail { get; set; }

        //[Required]
        public string? Picture { get; set; } // Assuming the URL or path of the picture

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than zero.")]
        public decimal Price { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least one.")]
        public int Quantity { get; set; }

        public decimal TotalPrice => Price * Quantity;

        [Required]
        public DateTime CreatedDate { get; set; }
    }
}
