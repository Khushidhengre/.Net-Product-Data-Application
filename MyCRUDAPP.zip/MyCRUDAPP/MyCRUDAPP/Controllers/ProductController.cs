﻿
// Controllers/ProductController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using MyCRUDAPP.Models;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace MyCRUDAPP.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProductController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Controllers/ProductController.cs
        public async Task<IActionResult> Index(string searchString, DateTime? startDate, DateTime? endDate, int page = 1)
        {
            var products = _context.Products.AsQueryable();

            if (!string.IsNullOrEmpty(searchString))
            {
                products = products.Where(p => p.Name.Contains(searchString));
            }

            if (startDate.HasValue && endDate.HasValue)
            {
                products = products.Where(p => p.CreatedDate >= startDate && p.CreatedDate <= endDate);
            }

            products = products.OrderBy(p => p.CreatedDate);

            int pageSize = 10;
            var pagedProducts = await products.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling((double)await products.CountAsync() / pageSize);

            ViewData["SearchString"] = searchString;
            ViewData["StartDate"] = startDate?.ToString("yyyy-MM-dd");
            ViewData["EndDate"] = endDate?.ToString("yyyy-MM-dd");

            return View(pagedProducts);
        }




        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile fileUpload)
        {
            if (fileUpload != null && fileUpload.Length > 0)
            {
                // Define the path to save the file
                var uploads = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
                var filePath = Path.Combine(uploads, fileUpload.FileName);

                // Create the directory if it doesn't exist
                if (!Directory.Exists(uploads))
                {
                    Directory.CreateDirectory(uploads);
                }

                // Save the file
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await fileUpload.CopyToAsync(stream);
                }

                // Assuming you have a model to update the file path
                // Here you would need to handle updating the database with the file path
                var product = new Product
                {
                    Picture = fileUpload.FileName,
                    // other properties
                };

                // Save the product to the database
                _context.Products.Add(product);
                await _context.SaveChangesAsync();

                // Redirect or return appropriate response
                return RedirectToAction("Index");
            }

            // Handle errors or return an error response
            return BadRequest("No file uploaded.");
        }




        [HttpPost]
        public async Task<IActionResult> Create([FromForm] Product model, IFormFile pictureFile)
        {
            // Check if the model state is valid
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors)
                                              .Select(e => e.ErrorMessage)
                                              .ToList();
                return BadRequest(new { error = "Invalid data.", details = errors });
            }

            // Handle the picture file if provided
            string picturePath = null;
            if (pictureFile != null && pictureFile.Length > 0)
            {
                try
                {
                    var uploadDir = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
                    if (!Directory.Exists(uploadDir))
                    {
                        Directory.CreateDirectory(uploadDir);
                    }

                    var fileName = Guid.NewGuid().ToString() + Path.GetExtension(pictureFile.FileName);
                    var filePath = Path.Combine(uploadDir, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await pictureFile.CopyToAsync(stream);
                    }

                    picturePath = $"/uploads/{fileName}";
                }
                catch (Exception ex)
                {
                    return BadRequest(new { error = "Error processing image: " + ex.Message });
                }
            }

            // Create the product instance
            var product = new Product
            {
                Name = model.Name,
                Detail = model.Detail,
                Picture = picturePath,
                Price = model.Price,
                Quantity = model.Quantity,
               // TotalPrice = model.Price * model.Quantity,
                CreatedDate = DateTime.Now
            };

            try
            {
                _context.Products.Add(product);
                await _context.SaveChangesAsync();

                // After saving, the Id should be automatically assigned
                return Ok(new
                {
                    Id = product.Id,
                    TotalPrice = product.TotalPrice,
                    CreatedDate = product.CreatedDate,
                    PictureUrl = Url.Content(product.Picture)
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "An error occurred while saving the product: " + ex.Message });
            }
        }


        //[HttpPost]
        //public async Task<IActionResult> Create([FromForm] Product model, IFormFile pictureFile)
        //{
        //    // Check if the model state is valid
        //    if (!ModelState.IsValid)
        //    {
        //        // Collect and return validation errors
        //        var errors = ModelState.Values.SelectMany(v => v.Errors)
        //                                      .Select(e => e.ErrorMessage)
        //                                      .ToList();
        //        return BadRequest(new { error = "Invalid data.", details = errors });
        //    }

        //    // Handle the picture file if provided
        //    string picturePath = null;
        //    if (pictureFile != null && pictureFile.Length > 0)
        //    {
        //        try
        //        {
        //            // Ensure the uploads directory exists
        //            var uploadDir = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
        //            if (!Directory.Exists(uploadDir))
        //            {
        //                Directory.CreateDirectory(uploadDir);
        //            }

        //            // Generate a unique file name
        //            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(pictureFile.FileName);
        //            var filePath = Path.Combine(uploadDir, fileName);

        //            // Save the file
        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await pictureFile.CopyToAsync(stream);
        //            }

        //            picturePath = $"/uploads/{fileName}";
        //        }
        //        catch (Exception ex)
        //        {
        //            // Log the exception and return a bad request response
        //            // You should also consider logging the error for debugging
        //            return BadRequest(new { error = "Error processing image: " + ex.Message });
        //        }
        //    }

        //    // Create the product instance
        //    var product = new Product
        //    {
        //        Name = model.Name,
        //        Detail = model.Detail,
        //        Picture = picturePath,
        //        Price = model.Price,
        //        Quantity = model.Quantity,
        //      //  TotalPrice = model.Price * model.Quantity,
        //        CreatedDate = DateTime.Now
        //    };

        //    try
        //    {
        //        // Add the product to the context and save changes
        //        _context.Products.Add(product);
        //        await _context.SaveChangesAsync();

        //        // Return a success response
        //        return Ok(new
        //        {
        //            Id = product.Id,
        //            TotalPrice = product.TotalPrice,
        //            CreatedDate = product.CreatedDate,
        //            PictureUrl = Url.Content(product.Picture)
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        // Log the exception and return an internal server error response
        //        // Consider logging the error for debugging purposes
        //        return StatusCode(500, new { error = "An error occurred while saving the product: " + ex.Message });
        //    }
        //}





        [HttpPost]
        public async Task<IActionResult> Update(int id, [FromForm] Product model, IFormFile pictureFile)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            product.Name = model.Name;
            product.Detail = model.Detail;
            product.Price = model.Price;
            product.Quantity = model.Quantity;
           // product.TotalPrice = product.Price * product.Quantity;

            if (pictureFile != null && pictureFile.Length > 0)
            {
                try
                {
                    var fileName = Guid.NewGuid().ToString() + Path.GetExtension(pictureFile.FileName);
                    var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await pictureFile.CopyToAsync(stream);
                    }

                    product.Picture = $"/uploads/{fileName}";
                }
                catch (Exception ex)
                {
                    return BadRequest(new { error = "Error processing image: " + ex.Message });
                }
            }

            try
            {
                _context.Products.Update(product);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    TotalPrice = product.TotalPrice,
                    CreatedDate = product.CreatedDate,
                    PictureUrl = Url.Content(product.Picture)
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "An error occurred while saving the product: " + ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Product model, IFormFile pictureFile)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors)
                                              .Select(e => e.ErrorMessage)
                                              .ToList();
                return Json(new { error = "Invalid data", details = errors });
            }

            var product = await _context.Products.FindAsync(model.Id);
            if (product == null)
            {
                return NotFound();
            }

            product.Name = model.Name;
            product.Detail = model.Detail;
            product.Price = model.Price;
            product.Quantity = model.Quantity;
            product.CreatedDate = DateTime.Now;

            // Handle file upload
            if (pictureFile != null && pictureFile.Length > 0)
            {
                var fileName = Path.GetFileName(pictureFile.FileName);
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", fileName);

                try
                {
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await pictureFile.CopyToAsync(stream);
                    }
                    product.Picture = fileName;
                }
                catch (Exception ex)
                {
                    return Json(new { error = "File upload failed: " + ex.Message });
                }
            }

            _context.Products.Update(product);
            await _context.SaveChangesAsync();

            return Json(new
            {
                Id = product.Id,
                TotalPrice = product.Price * product.Quantity,
                CreatedDate = product.CreatedDate,
                PictureUrl = Url.Content("~/uploads/" + product.Picture)
            });
        }


         [HttpPost]
        public async Task<IActionResult> Delete(int  id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
